$( document ).ready(function() {
  $('.search-query').bind('railsAutocomplete.select', function(event, data {
  $('.search-me').trigger('click')
  });
});
